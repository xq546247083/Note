﻿using Windows.UI.Xaml;

namespace CodeIntroUWP
{
    public class Program
    {
        public static void Main()
        {
            Application.Start(p => new App());
        }
    }
}
