package main

func main() {
	go println("Go! Goroutine!")
}
