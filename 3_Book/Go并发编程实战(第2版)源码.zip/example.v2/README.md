# example.v2
An example project for book 'Go Programming &amp; Concurrency in Practice, 2nd edition' (《Go并发编程实战》第2版).
