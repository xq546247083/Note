﻿namespace SharingSource.Models
{
    public class Book
    {
        public string Title { get; set; }
        public string Publisher { get; set; }
    }
}
