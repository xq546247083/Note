﻿namespace Wrox.ProCSharp.Composition
{
    public class Operation : IOperation
    {
        public string Name { get; internal set; }
        public int NumberOperands { get; internal set; }
    }
}
