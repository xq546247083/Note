# Readme - Code Samples for Chapter 40, ASP.NET Core

This chapter contains this sample:

* WebSampleApp

Building this sample starts with an empty ASP.NET Core Web project, and adds many features of ASP.NET Core.

To build and run the .NET Core samples, please install
* Visual Studio 2017 with the .NET Core workload

Please download and install the tools from [.NET Core downloads](https://www.microsoft.com/net/core).
 
For code comments and issues please check [Professional C#'s GitHub Repository](https://github.com/ProfessionalCSharp/ProfessionalCSharp6)

Please check my blog [csharp.christiannagel.com](https://csharp.christiannagel.com "csharp.christiannagel.com") for additional information for topics covered in the book.

Thank you!