﻿using static System.Console;

namespace Wrox.HelloWorldApp
{
    class Program
    {
        static void Main()
        {
            WriteLine("Hello, World!");
        }
    }
}
