﻿using static System.Console;

namespace SyntaxTreeSample
{
    // Hello World! Sample Program
    public class Program
    {
        // Hello World! Sample Method
        public static void Hello()
        {
            WriteLine("Hello, World!");
        }
    }
}
